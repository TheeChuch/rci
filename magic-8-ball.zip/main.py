# import the modules
import sys
import random

ans = True
while ans:
  question =input ("Ask the magic 8 ball a question: (press enter to quit) ")

  answers = random.randint(1,16)

  if question == "":
   sys.exit()

  elif answers == 1:
   print ("It is certain")
    
  elif answers == 2:
        print("Outlook good")
    
  elif answers == 3:
        print("You may rely on it")
    
  elif answers == 4:
        print("Ask again later")
    
  elif answers == 5:
        print("Concentrate and ask again")
    
  elif answers == 6:
        print("Reply hazy, try again")
    
  elif answers == 7:
        print("My reply is no")
    
  elif answers == 8:
        print("My sources say no")

  elif answers == 9:
        print("Does Rose Kennedy own a black dress?")

  elif answers == 10:
        print("Are you high?")

  elif answers == 11:
        print("Does a one legged duck swim in a circle?")

  elif answers == 12:
        print("Yeah right")

  elif answers == 13:
        print("There is some chance")

  elif answers == 14:
        print("One in a million shot")

  elif answers == 15:
        print("When hell freezes over")

  elif answers == 16:
        print("If I were a betting man I would say yes")