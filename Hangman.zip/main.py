import random

words = ["funny", "foolhardy", "unanimous","spectacular","helicopter","forceful""handyman"]

def update_dashes(secret, cur_dash, rec_guess):
  result = ""
  
  for i in range(len(secret)):
    if secret[i] == rec_guess:
      result = result + rec_guess     
      
    else:
      result = result + cur_dash[i]
      
  return result

def get_guess():
  
  dashes = "-" * len(secret_word)
  guesses_left = 10
  
  while guesses_left > -1 and not dashes == secret_word:
    
    print(dashes)
    print (str(guesses_left))
    
    guess = input("Guess:")
    
    guess = guess.lower()
    
    if len(guess) !=1:
      print ("Only guess one letter!")
      
    elif guess in secret_word:
      print ("Yay, You guessed a letter!")
      dashes = update_dashes(secret_word, dashes, guess)
      
    else:
      print ("Wrong! That letters not in the word!")
      guesses_left -= 1
    
  if guesses_left < 0:
    print ("You lose. The word was: " + str(secret_word))
  
  else:
    print ("Congrats! You got the word!. The word was: " + str(secret_word))
    
secret_word = random.choice(words)
get_guess()